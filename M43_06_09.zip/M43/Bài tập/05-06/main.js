var a = [-12, 2, 3, 5, 2, -14, -14, -14, 4, 1, 5, 3, 11, 22, 33, 33];
// var a = [1, 1, 1, 1, 1, 1, 1, 1, 2];

function checkInteger(array) {
  for (var i = 0; i < array.length; i++) {
    // console.log("array[" + i + "]: " + (array[i] % 1));
    // if (array[i] % 1 !== 0) return false;
    // if (!Number.isInteger(array[i])) {
    //   return false;
    // }
    if (Math.ceil(array[i]) !== Math.floor(array[i])) {
      return false;
    }
  }
  return true;
}
console.log(checkInteger(a));

function averageArray(array) {
  return (
    array.reduce(function (s, item) {
      return s + item;
    }, 0) / array.length
  ).toFixed(2);
}
console.log(averageArray(a));

function aseSort(array) {
  //   var newArr = array.map(function (item) {
  //     return item;
  //   });
  //   var newArr = array.slice();
  //   var newArr = array.filter(function () {
  //     return true;
  //   });
  var newArr = Array.from(array);
  newArr.sort(function (a, b) {
    return a - b;
  });
  return newArr;
}

function desSort(array) {
  var newArr = Array.from(array);
  newArr.sort(function (a, b) {
    return b - a;
  });
  return newArr;
}

// console.log("A: " + a);
console.log("Sort: " + desSort(a));
// console.log("A: " + a);

function findMaxValue(array) {
  var maxValue = array[0];
  for (var i = 1; i < array.length; i++) {
    if (maxValue < array[i]) {
      maxValue = array[i];
    }
  }
  return maxValue;
}
// console.log("A: " + a);
// console.log(findMaxValue(a));

function findMinValue(array) {
  var minValue = array[0];
  for (var i = 1; i < array.length; i++) {
    if (minValue > array[i]) {
      minValue = array[i];
    }
  }
  return minValue;
}

// console.log("A: " + a);
// console.log(findMinValue(a));

function insert(array) {
  var newArr = Array.from(array);
  newArr.splice(4, 0, +averageArray(array));
  return newArr;
}

function elementsMTA(array) {
  var average = +averageArray(array);
  var result = array.filter(function (item) {
    return item > average;
  });
  return result;
}

function elementsLTA(array) {
  var average = +averageArray(array);
  var result = array.filter(function (item) {
    return item < average;
  });
  return result;
}
console.log(elementsLTA(a));

function evenElements(array) {
  var result = array.filter(function (item) {
    return item % 2 === 0;
  });
  return result;
}
console.log(evenElements(a));

function oddElements(array) {
  var result = array.filter(function (item) {
    return item % 2 !== 0;
  });
  return result;
}
console.log(oddElements(a));

function speSum(array) {
  var newArr = desSort(array);
  var lastMaxValueIndex = newArr.lastIndexOf(newArr[0]);
  var secondMaxValueIndex = lastMaxValueIndex + 1; /////// 1
  var firstMinValueIndex = newArr.indexOf(newArr[newArr.length - 1]);
  var secondMinValueIndex = firstMinValueIndex - 1; /////// 2
  if (newArr[0] === newArr[newArr.length - 1]) {
    return "Min = max";
  }
  return newArr[secondMaxValueIndex] + newArr[secondMinValueIndex];
}

console.log(speSum(a));

function evenFisrt(array) {
  var newArr = aseSort(array);
  var evens = evenElements(newArr);
  var oods = oddElements(newArr);
  return evens.concat(oods);
}

console.log(evenFisrt(a));
